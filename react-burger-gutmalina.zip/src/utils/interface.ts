export interface IRouter {
  element: JSX.Element,
  onlyUnAuth?: boolean
}
